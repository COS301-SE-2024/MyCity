**To delete an integration for a given resource and method in an API**

Command::

  aws apigateway delete-integration --rest-api-id 1234123412 --resource-id a1b2c3 --http-method GET
